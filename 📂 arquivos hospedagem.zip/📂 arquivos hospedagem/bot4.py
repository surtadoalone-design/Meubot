import discord
from discord.ext import commands
from discord import app_commands
import random
import json
import os
import asyncio
from datetime import datetime
from collections import Counter

# ================================================================
#   CONFIGURACOES
# ================================================================

TOKEN   ="MTQ4OTM3NDQzNTczMDUyMjE1Mg.G93-AA.1V0Y3PDSCbHpjKsDHBTKm6grz4O_1cMz8RU7Ew"  # <- COLOQUE SEU NOVO TOKEN AQUI

GUILD_ID             = 1475588137450471580
CATEGORY_ID          = 1475605591165505670
APOSTA_CATEGORY_ID   = 1491185464894423080
SUPORTE_CHANNEL_ID   = 1489406764704337920
LOG_CHANNEL_ID       = 0
SUPORTE_ROLE_ID      = 1489407222554300426
NOVATO_ROLE_ID       = 1475592229723701248  # cargo membro atualizado
ADM_PARTIDAS_CHANNEL_ID = 1491189336555786290

# Preencha apos criar os canais
DASHBOARD_CHANNEL_ID = 1491189336555786290
TICKET_CHANNEL_ID    = 1501540869835063387
TICKET_CATEGORY_ID   = 1475592274774855842
TICKET_ROLE_ID       = 1489407222554300426
VOICE_CATEGORY_ID    = 1475625751872016465

GIF_URL = "https://cdn.discordapp.com/attachments/1491189336555786290/1501869377035702272/file_000000000dd871f5b6d3e10affff5bcf.gif?ex=69fda45a&is=69fc52da&hm=1771748a9f68e75cfda99d307d02ec3f615fdc82106e3a20eff5be4cd45df8e3&"

PONTOS_VENCEDOR = 1.5
PONTOS_MVP      = 0.8
RANK_VITORIA    = -3
RANK_DERROTA    = 2

VALORES_APOSTA = [
    "R$ 0,50",  "R$ 1,00",  "R$ 2,00",  "R$ 3,00",
    "R$ 6,00",  "R$ 10,00", "R$ 20,00", "R$ 40,00",
    "R$ 50,00", "R$ 100,00"
]

# ================================================================
#   PERSISTENCIA
# ================================================================

DATA_FILE       = "dados.json"
FILA_MSG_FILE   = "fila_msg.json"
APOSTA_CFG_FILE = "aposta_cfg.json"
ADM_FILE        = "adms.json"
TICKET_FILE     = "tickets.json"
PARTIDA_NUM_FILE = "partida_num.json"

def carregar_json(arq, pad):
    if os.path.exists(arq):
        with open(arq, "r") as f:
            return json.load(f)
    return pad

def salvar_json(arq, d):
    with open(arq, "w") as f:
        json.dump(d, f, indent=2)

dados       = carregar_json(DATA_FILE,        {"jogadores": {}})
fila_cfg    = carregar_json(FILA_MSG_FILE,    {})
aposta_cfg  = carregar_json(APOSTA_CFG_FILE,  {})
adms_dados  = carregar_json(ADM_FILE,         {})
ticket_data = carregar_json(TICKET_FILE,      {"count": 0})
partida_num_data = carregar_json(PARTIDA_NUM_FILE, {"count": 0})

adms_online = set()
tickets_abertos = {}

def salvar_dados():  salvar_json(DATA_FILE,        dados)
def salvar_adms():   salvar_json(ADM_FILE,          adms_dados)
def salvar_fila(d):  salvar_json(FILA_MSG_FILE,     d)

def proximo_num_partida():
    partida_num_data["count"] += 1
    salvar_json(PARTIDA_NUM_FILE, partida_num_data)
    return str(partida_num_data["count"]).zfill(4)

def proximo_num_ticket():
    ticket_data["count"] += 1
    salvar_json(TICKET_FILE, ticket_data)
    return str(ticket_data["count"]).zfill(4)

# ================================================================
#   ESTADO GLOBAL
# ================================================================

filas = {
    "1v1": {"gelo_normal": [], "gelo_infinito": []},
    "2v2": {"gelo_normal": [], "gelo_infinito": []},
    "3v3": {"gelo_normal": [], "gelo_infinito": []},
}
filas_times = {
    t: {m: {"time1": [], "time2": []} for m in ["gelo_normal","gelo_infinito"]}
    for t in ["2v2","3v3"]
}
partidas_ativas   = {}
painel_ids        = {t: int(fila_cfg.get(t+"_msg", 0))   for t in ["1v1","2v2","3v3"]}
painel_canal_ids  = {t: int(fila_cfg.get(t+"_canal", 0)) for t in ["1v1","2v2","3v3"]}

aposta_filas_1v1 = {v: {"gelo_normal": [], "gelo_infinito": []} for v in VALORES_APOSTA}
aposta_filas_eq  = {t: {v: [] for v in VALORES_APOSTA} for t in ["2v2","3v3","4v4"]}
aposta_partidas  = {}

def _load_aposta_val(tipo):
    result = {}
    for v in VALORES_APOSTA:
        km = tipo+"_"+v+"_msg"
        kc = tipo+"_"+v+"_canal"
        if km in aposta_cfg:
            result[v] = {"msg": int(aposta_cfg[km]), "canal": int(aposta_cfg.get(kc, 0))}
    return result

aposta_painel_val_ids = {t: _load_aposta_val(t) for t in ["1v1","2v2","3v3","4v4"]}
adm_painel_msg_id     = int(aposta_cfg.get("adm_msg", 0))

# ================================================================
#   BOT
# ================================================================

intents                 = discord.Intents.default()
intents.members         = True
intents.message_content = True
bot  = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# ================================================================
#   HELPERS
# ================================================================

def get_perfil(uid):
    s = str(uid)
    if s not in dados["jogadores"]:
        dados["jogadores"][s] = {"vitorias":0,"derrotas":0,"pontos":0.0,"mvps":0,"apelido_num":None}
        salvar_dados()
    return dados["jogadores"][s]

def numero_unico():
    usados = {v.get("apelido_num") for v in dados["jogadores"].values() if v.get("apelido_num")}
    while True:
        n = str(random.randint(1000,9999))
        if n not in usados: return n

def is_adm(interaction):
    role = interaction.guild.get_role(SUPORTE_ROLE_ID)
    return (role in interaction.user.roles) or interaction.user.guild_permissions.administrator

def nome_m(guild, uid):
    m = guild.get_member(uid)
    return m.display_name if m else str(uid)

def rank_str(uid):
    p = get_perfil(uid)
    return "RANK " + str(p.get("apelido_num") or "????")

def slot_rank(guild, uid):
    if uid is None: return "Aguardando..."
    m = guild.get_member(uid)
    nome = m.display_name if m else str(uid)
    return rank_str(uid) + " | " + nome

def esta_em_fila_ranked(uid):
    for tf in filas.values():
        for lista in tf.values():
            if uid in lista: return True
    return False

def esta_em_partida(uid):
    for info in list(partidas_ativas.values()) + list(aposta_partidas.values()):
        if uid in info["jogadores"]: return True
    return False

def esta_em_fila_aposta(uid):
    for md in aposta_filas_1v1.values():
        for l in md.values():
            if uid in l: return True
    for td in aposta_filas_eq.values():
        for l in td.values():
            if uid in l: return True
    return False

def parece_codigo(texto):
    nums = sum(1 for c in texto if c.isdigit())
    return nums >= 4 and (nums / max(len(texto.replace(" ","")),1)) > 0.5

async def nick_update(guild, uid):
    p = get_perfil(uid); m = guild.get_member(uid)
    if not m: return
    nick = ("RANK " + str(p.get("apelido_num") or "????") + " | " + m.name)[:32]
    try: await m.edit(nick=nick)
    except: pass

def adm_online_txt():
    if adms_online:
        return "ADM ON: " + " | ".join(adms_dados.get(str(u),{}).get("nome", str(u)) for u in adms_online)
    return "SEM ADM DISPONIVEL"

def usuario_em_call(guild, uid):
    if not VOICE_CATEGORY_ID: return True
    cat = guild.get_channel(VOICE_CATEGORY_ID)
    if not cat: return True
    for ch in cat.channels:
        if isinstance(ch, discord.VoiceChannel):
            for m in ch.members:
                if m.id == uid: return True
    return False

# ================================================================
#   EMBEDS RANKED — 1v1
# ================================================================

def build_1v1():
    guild = bot.get_guild(GUILD_ID)
    embed = discord.Embed(title="1v1 Mobile  |  RANKED", color=0x00aaff)
    embed.set_thumbnail(url=GIF_URL)
    for modo, label in [("gelo_normal","Gelo Normal"),("gelo_infinito","Gelo Infinito")]:
        lista = filas["1v1"][modo]
        c1 = lista[0] if len(lista)>0 else None
        c2 = lista[1] if len(lista)>1 else None
        embed.add_field(
            name=label + "  (" + str(len(lista)) + "/2)",
            value="Capitao 1: " + slot_rank(guild,c1) + "\nCapitao 2: " + slot_rank(guild,c2),
            inline=True
        )
    embed.set_footer(text="Selecione o modo e entre na fila!")
    return embed

def build_2v2():
    guild = bot.get_guild(GUILD_ID)
    embed = discord.Embed(title="2v2 Mobile  |  RANKED", color=0x00ff88)
    embed.set_thumbnail(url=GIF_URL)
    for modo, label in [("gelo_normal","Gelo Normal"),("gelo_infinito","Gelo Infinito")]:
        t1 = filas_times["2v2"][modo]["time1"]
        t2 = filas_times["2v2"][modo]["time2"]
        total = len(t1)+len(t2)
        txt1 = "\n".join(slot_rank(guild,u) for u in t1) or "Aguardando..."
        txt2 = "\n".join(slot_rank(guild,u) for u in t2) or "Aguardando..."
        embed.add_field(name=label+" ("+str(total)+"/4)", value="\u200b", inline=False)
        embed.add_field(name="TIME 1", value=txt1, inline=True)
        embed.add_field(name="TIME 2", value=txt2, inline=True)
    embed.set_footer(text="Voce sera alocado aleatoriamente em um time!")
    return embed

def build_3v3():
    guild = bot.get_guild(GUILD_ID)
    embed = discord.Embed(title="3v3 Mobile  |  RANKED", color=0xff8800)
    embed.set_thumbnail(url=GIF_URL)
    for modo, label in [("gelo_normal","Gelo Normal"),("gelo_infinito","Gelo Infinito")]:
        t1 = filas_times["3v3"][modo]["time1"]
        t2 = filas_times["3v3"][modo]["time2"]
        total = len(t1)+len(t2)
        txt1 = "\n".join(slot_rank(guild,u) for u in t1) or "Aguardando..."
        txt2 = "\n".join(slot_rank(guild,u) for u in t2) or "Aguardando..."
        embed.add_field(name=label+" ("+str(total)+"/6)", value="\u200b", inline=False)
        embed.add_field(name="TIME 1", value=txt1, inline=True)
        embed.add_field(name="TIME 2", value=txt2, inline=True)
    embed.set_footer(text="Voce sera alocado aleatoriamente em um time!")
    return embed

def get_embed_ranked(tipo):
    if tipo=="1v1": return build_1v1()
    if tipo=="2v2": return build_2v2()
    return build_3v3()

# ================================================================
#   EMBEDS APOSTAS
# ================================================================

def build_aposta_1v1(valor):
    cor   = 0x00ff55 if adms_online else 0xff3333
    guild = bot.get_guild(GUILD_ID)
    embed = discord.Embed(title="1v1  |  " + valor, color=cor)
    embed.set_thumbnail(url=GIF_URL)
    embed.add_field(name="Status ADM", value=adm_online_txt(), inline=False)
    for modo, label in [("gelo_normal","Gelo Normal"),("gelo_infinito","Gelo Infinito")]:
        lista = aposta_filas_1v1[valor][modo]
        j1 = slot_rank(guild,lista[0]) if len(lista)>0 else "Aguardando..."
        j2 = slot_rank(guild,lista[1]) if len(lista)>1 else "Aguardando..."
        embed.add_field(
            name=label+" ("+str(len(lista))+"/2)",
            value="J1: "+j1+"\nJ2: "+j2,
            inline=True
        )
    embed.set_footer(text="Apenas disponivel com ADM online")
    return embed

def build_aposta_eq(tipo, valor):
    cor   = 0x00ff55 if adms_online else 0xff3333
    guild = bot.get_guild(GUILD_ID)
    embed = discord.Embed(title=tipo+" Mobile  |  "+valor, color=cor)
    embed.set_thumbnail(url=GIF_URL)
    embed.add_field(name="Status ADM", value=adm_online_txt(), inline=False)
    lista = aposta_filas_eq[tipo][valor]
    j1 = slot_rank(guild,lista[0]) if len(lista)>0 else "Aguardando..."
    j2 = slot_rank(guild,lista[1]) if len(lista)>1 else "Aguardando..."
    embed.add_field(name="Fila ("+str(len(lista))+"/2)", value="J1: "+j1+"\nJ2: "+j2, inline=False)
    embed.set_footer(text="Cada jogador representa seu time completo")
    return embed

def build_adm_painel():
    guild = bot.get_guild(GUILD_ID)
    embed = discord.Embed(title="PAINEL ADM  |  RANKED", color=0x5865f2)
    embed.set_thumbnail(url=GIF_URL)
    if not adms_dados:
        embed.add_field(name="Nenhum ADM", value="Use Registrar para cadastrar.", inline=False)
    else:
        for uid_s, d in adms_dados.items():
            uid  = int(uid_s)
            stat = "ONLINE" if uid in adms_online else "offline"
            embed.add_field(name=d.get("nome",uid_s)+"  ["+stat+"]", value="PIX: "+d.get("pix","?"), inline=False)
    embed.set_footer(text="ADMs: use os botoes abaixo para gerenciar")
    return embed

# ================================================================
#   VIEWS RANKED
# ================================================================

class PainelRankedView(discord.ui.View):
    def __init__(self, tipo):
        super().__init__(timeout=None)
        self.tipo = tipo
        cores = {"1v1":discord.ButtonStyle.primary,"2v2":discord.ButtonStyle.success,"3v3":discord.ButtonStyle.danger}
        cor   = cores.get(tipo, discord.ButtonStyle.primary)

        if tipo == "1v1":
            b1 = discord.ui.Button(label="Gelo Normal",   style=cor,                        custom_id=tipo+"_gn",  row=0)
            b2 = discord.ui.Button(label="Gelo Infinito", style=cor,                        custom_id=tipo+"_gi",  row=0)
            b3 = discord.ui.Button(label="Sair da Fila",  style=discord.ButtonStyle.danger, custom_id=tipo+"_out", row=1)
            async def cb1(i): await ranked_entrar(i, tipo, "gelo_normal")
            async def cb2(i): await ranked_entrar(i, tipo, "gelo_infinito")
            async def cb3(i): await ranked_sair(i)
            b1.callback=cb1; b2.callback=cb2; b3.callback=cb3
            self.add_item(b1); self.add_item(b2); self.add_item(b3)
        else:
            b1 = discord.ui.Button(label="Entrar",       style=cor,                        custom_id=tipo+"_ent", row=0)
            b2 = discord.ui.Button(label="Sair da Fila", style=discord.ButtonStyle.danger, custom_id=tipo+"_out", row=0)
            async def cb1(i): await ranked_entrar(i, tipo, "gelo_normal")
            async def cb2(i): await ranked_sair(i)
            b1.callback=cb1; b2.callback=cb2
            self.add_item(b1); self.add_item(b2)

async def ranked_sair(interaction):
    uid  = interaction.user.id
    saiu = False
    for tf in filas.values():
        for lista in tf.values():
            if uid in lista: lista.remove(uid); saiu=True
    for t in ["2v2","3v3"]:
        for m in ["gelo_normal","gelo_infinito"]:
            for tk in ["time1","time2"]:
                if uid in filas_times[t][m][tk]: filas_times[t][m][tk].remove(uid); saiu=True
    if saiu:
        await interaction.response.send_message("Voce saiu da fila!", ephemeral=True)
        asyncio.create_task(update_all_ranked(interaction.guild))
    else:
        await interaction.response.send_message("Voce nao esta em nenhuma fila.", ephemeral=True)

async def ranked_entrar(interaction, tipo, modo):
    uid   = interaction.user.id
    max_j = {"1v1":2,"2v2":4,"3v3":6}[tipo]

    if esta_em_fila_ranked(uid) or esta_em_fila_aposta(uid):
        return await interaction.response.send_message("Voce ja esta em uma fila!", ephemeral=True)
    if esta_em_partida(uid):
        return await interaction.response.send_message("Voce ja esta em uma partida ativa!", ephemeral=True)

    filas[tipo][modo].append(uid)
    time_info = ""

    if tipo in ("2v2","3v3"):
        metade = max_j // 2
        t1 = filas_times[tipo][modo]["time1"]
        t2 = filas_times[tipo][modo]["time2"]
        if len(t1) <= len(t2) and len(t1) < metade:
            escolha = "time1"
        elif len(t2) < metade:
            escolha = "time2"
        else:
            escolha = random.choice(["time1","time2"])
        filas_times[tipo][modo][escolha].append(uid)
        num = "1" if escolha=="time1" else "2"
        time_info = "  |  TIME " + num

    atual = len(filas[tipo][modo])
    await interaction.response.send_message(
        "Voce entrou na fila " + tipo + "! (" + str(atual) + "/" + str(max_j) + ")" + time_info,
        ephemeral=True
    )
    asyncio.create_task(update_ranked(interaction.guild, tipo))

    if atual >= max_j:
        if tipo in ("2v2","3v3"):
            t1 = filas_times[tipo][modo]["time1"][:]
            t2 = filas_times[tipo][modo]["time2"][:]
            jogadores = t1 + t2
            filas_times[tipo][modo]["time1"].clear()
            filas_times[tipo][modo]["time2"].clear()
        else:
            jogadores = [filas[tipo][modo].pop(0) for _ in range(max_j)]
        while filas[tipo][modo]: filas[tipo][modo].pop(0)
        asyncio.create_task(update_ranked(interaction.guild, tipo))
        asyncio.create_task(criar_partida_ranked(interaction.guild, jogadores, tipo, modo))

async def update_all_ranked(guild):
    for t in ["1v1","2v2","3v3"]: await update_ranked(guild, t)

async def update_ranked(guild, tipo):
    mid = painel_ids.get(tipo,0); cid = painel_canal_ids.get(tipo,0)
    if not mid or not cid: return
    ch = guild.get_channel(cid)
    if not ch: return
    try:
        msg = await ch.fetch_message(mid)
        await msg.edit(embed=get_embed_ranked(tipo), view=PainelRankedView(tipo))
    except Exception as e: print("[ERRO update_ranked "+tipo+"] "+str(e))

# ================================================================
#   VIEWS APOSTAS
# ================================================================

def _vid(valor): return valor.replace("R$ ","").replace(",","_")

class ApostaVal1v1View(discord.ui.View):
    def __init__(self, valor):
        super().__init__(timeout=None)
        vid = _vid(valor)
        b1 = discord.ui.Button(label="Gelo Normal",   style=discord.ButtonStyle.success, custom_id="ap1_"+vid+"_gn",   row=0)
        b2 = discord.ui.Button(label="Gelo Infinito", style=discord.ButtonStyle.success, custom_id="ap1_"+vid+"_gi",   row=0)
        b3 = discord.ui.Button(label="Sair",          style=discord.ButtonStyle.danger,  custom_id="ap1_"+vid+"_sair", row=1)
        async def c1(i): await ap1v1_entrar(i, valor, "gelo_normal")
        async def c2(i): await ap1v1_entrar(i, valor, "gelo_infinito")
        async def c3(i): await ap_sair(i)
        b1.callback=c1; b2.callback=c2; b3.callback=c3
        self.add_item(b1); self.add_item(b2); self.add_item(b3)

class ApostaValEqView(discord.ui.View):
    def __init__(self, tipo, valor):
        super().__init__(timeout=None)
        vid = _vid(valor)
        b1 = discord.ui.Button(label="Entrar", style=discord.ButtonStyle.success, custom_id="apeq_"+tipo+"_"+vid+"_ent",  row=0)
        b2 = discord.ui.Button(label="Sair",   style=discord.ButtonStyle.danger,  custom_id="apeq_"+tipo+"_"+vid+"_sair", row=0)
        async def c1(i): await ap_eq_entrar(i, tipo, valor)
        async def c2(i): await ap_sair(i)
        b1.callback=c1; b2.callback=c2
        self.add_item(b1); self.add_item(b2)

async def ap_sair(interaction):
    uid = interaction.user.id; saiu = False
    for md in aposta_filas_1v1.values():
        for l in md.values():
            if uid in l: l.remove(uid); saiu=True
    for td in aposta_filas_eq.values():
        for l in td.values():
            if uid in l: l.remove(uid); saiu=True
    if saiu:
        await interaction.response.send_message("Voce saiu da fila de apostas!", ephemeral=True)
        asyncio.create_task(update_all_apostas(interaction.guild))
    else:
        await interaction.response.send_message("Voce nao esta em nenhuma fila.", ephemeral=True)

async def ap1v1_entrar(interaction, valor, modo):
    if not adms_online: return await interaction.response.send_message("Sem ADM disponivel!", ephemeral=True)
    uid = interaction.user.id
    if esta_em_fila_aposta(uid) or esta_em_fila_ranked(uid): return await interaction.response.send_message("Voce ja esta em uma fila!", ephemeral=True)
    if esta_em_partida(uid): return await interaction.response.send_message("Voce ja esta em uma partida!", ephemeral=True)
    lista = aposta_filas_1v1[valor][modo]; lista.append(uid)
    await interaction.response.send_message("Fila 1v1 "+modo.replace("_"," ").title()+" "+valor+"! ("+str(len(lista))+"/2)", ephemeral=True)
    asyncio.create_task(update_aposta_val("1v1", valor, interaction.guild))
    if len(lista) >= 2:
        j1=lista.pop(0); j2=lista.pop(0)
        asyncio.create_task(update_aposta_val("1v1", valor, interaction.guild))
        asyncio.create_task(criar_partida_aposta(interaction.guild, [j1,j2], "1v1", modo, valor))

async def ap_eq_entrar(interaction, tipo, valor):
    if not adms_online: return await interaction.response.send_message("Sem ADM disponivel!", ephemeral=True)
    uid = interaction.user.id
    if esta_em_fila_aposta(uid) or esta_em_fila_ranked(uid): return await interaction.response.send_message("Voce ja esta em uma fila!", ephemeral=True)
    if esta_em_partida(uid): return await interaction.response.send_message("Voce ja esta em uma partida!", ephemeral=True)
    lista = aposta_filas_eq[tipo][valor]; lista.append(uid)
    await interaction.response.send_message("Fila "+tipo+" "+valor+"! ("+str(len(lista))+"/2)", ephemeral=True)
    asyncio.create_task(update_aposta_val(tipo, valor, interaction.guild))
    if len(lista) >= 2:
        j1=lista.pop(0); j2=lista.pop(0)
        asyncio.create_task(update_aposta_val(tipo, valor, interaction.guild))
        asyncio.create_task(criar_partida_aposta(interaction.guild, [j1,j2], tipo, "gelo_normal", valor))

async def update_aposta_val(tipo, valor, guild):
    d = aposta_painel_val_ids.get(tipo,{}).get(valor)
    if not d: return
    mid=d.get("msg",0); cid=d.get("canal",0)
    if not mid or not cid: return
    ch = guild.get_channel(cid)
    if not ch: return
    try:
        msg = await ch.fetch_message(mid)
        if tipo=="1v1": await msg.edit(embed=build_aposta_1v1(valor), view=ApostaVal1v1View(valor))
        else:           await msg.edit(embed=build_aposta_eq(tipo,valor), view=ApostaValEqView(tipo,valor))
    except Exception as e: print("[ERRO update_aposta "+tipo+" "+valor+"] "+str(e))

async def update_all_apostas(guild):
    for t in ["1v1","2v2","3v3","4v4"]:
        for v in VALORES_APOSTA:
            await update_aposta_val(t, v, guild)

# ================================================================
#   ADM PAINEL VIEW
# ================================================================

class ADMPainelView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)

    @discord.ui.button(label="Ficar Online",    style=discord.ButtonStyle.success,   custom_id="adm_on")
    async def on_(self, interaction, button):
        if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        uid = interaction.user.id
        if str(uid) not in adms_dados: return await interaction.response.send_message("Registre seus dados primeiro!", ephemeral=True)
        adms_online.add(uid)
        await interaction.response.send_message("Voce esta ONLINE!", ephemeral=True)
        asyncio.create_task(update_adm_painel(interaction.guild))
        asyncio.create_task(update_all_apostas(interaction.guild))

    @discord.ui.button(label="Ficar Offline",   style=discord.ButtonStyle.secondary, custom_id="adm_off")
    async def off_(self, interaction, button):
        if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        adms_online.discard(interaction.user.id)
        await interaction.response.send_message("Voce esta OFFLINE.", ephemeral=True)
        asyncio.create_task(update_adm_painel(interaction.guild))
        asyncio.create_task(update_all_apostas(interaction.guild))

    @discord.ui.button(label="Registrar Dados", style=discord.ButtonStyle.primary,   custom_id="adm_reg")
    async def reg_(self, interaction, button):
        if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        await interaction.response.send_modal(ModalADM())

async def update_adm_painel(guild):
    global adm_painel_msg_id
    if not adm_painel_msg_id: return
    ch = guild.get_channel(ADM_PARTIDAS_CHANNEL_ID)
    if not ch: return
    try:
        msg = await ch.fetch_message(adm_painel_msg_id)
        await msg.edit(embed=build_adm_painel(), view=ADMPainelView())
    except Exception as e: print("[ERRO update_adm] "+str(e))

class ModalADM(discord.ui.Modal, title="Registro ADM"):
    nome = discord.ui.TextInput(label="Nome/apelido", max_length=50)
    pix  = discord.ui.TextInput(label="Chave PIX", max_length=100)
    qr   = discord.ui.TextInput(label="URL QR Code (opcional)", required=False, max_length=300)
    async def on_submit(self, interaction):
        uid = str(interaction.user.id)
        adms_dados[uid] = {"nome":self.nome.value,"pix":self.pix.value,"qr":self.qr.value or ""}
        salvar_adms()
        await interaction.response.send_message("Preenchimento concluido!\nNome: "+self.nome.value+"\nPIX: "+self.pix.value, ephemeral=True)
        asyncio.create_task(update_adm_painel(interaction.guild))

# ================================================================
#   CRIAR PARTIDA RANKED
# ================================================================

async def criar_partida_ranked(guild, jogadores, tipo, modo):
    try:
        categoria    = guild.get_channel(CATEGORY_ID)
        suporte_role = guild.get_role(SUPORTE_ROLE_ID)
        metade       = len(jogadores)//2
        time1        = jogadores[:metade]
        time2        = jogadores[metade:]
        capitao1     = random.choice(time1)
        capitao2     = random.choice(time2)

        overw = {guild.default_role: discord.PermissionOverwrite(read_messages=False)}
        for uid in jogadores:
            m = guild.get_member(uid)
            if m: overw[m] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
        if suporte_role: overw[suporte_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

        num   = proximo_num_partida()
        canal = await guild.create_text_channel("partida-"+num, category=categoria, overwrites=overw)

        info = {
            "jogadores":jogadores,"time1":time1,"time2":time2,
            "capitao1":capitao1,"capitao2":capitao2,
            "tipo":tipo,"modo":modo,"criador":None,
            "vencedor":None,"mvp":None,"conf_fim":[],
            "canal_id":canal.id,
            "votos_venc":{},"conf_venc":[],"votos_mvp":{},"conf_mvp":[]
        }
        partidas_ativas[canal.id] = info

        cap1m = guild.get_member(capitao1)
        cap2m = guild.get_member(capitao2)
        ml    = "Gelo Normal" if modo=="gelo_normal" else "Gelo Infinito"

        def time_block(tlist, cap):
            linhas = []
            for u in tlist:
                m = guild.get_member(u)
                n = m.display_name if m else str(u)
                pref = "**[CAP]** " if u==cap else ""
                linhas.append(pref + rank_str(u) + " | " + n)
            return "\n".join(linhas) or "---"

        embed = discord.Embed(
            title="Partida #"+num+"  |  "+tipo.upper(),
            description=(
                "Bem-vindos a partida! Joguem com fair play.\n"
                "Para definir o criador: mande o codigo da sala no chat."
            ),
            color=0x1a1a2e
        )
        embed.set_thumbnail(url=GIF_URL)
        embed.add_field(name="Modo",  value=ml,                               inline=True)
        embed.add_field(name="Tipo",  value=tipo.upper(),                     inline=True)
        embed.add_field(name="Data",  value=datetime.now().strftime("%d/%m"), inline=True)
        embed.add_field(name="\u200b",value="\u200b",                         inline=False)

        if tipo=="1v1":
            p1 = get_perfil(time1[0]); p2 = get_perfil(time2[0])
            m1 = guild.get_member(time1[0]); m2 = guild.get_member(time2[0])
            embed.add_field(
                name="AZUL",
                value=rank_str(time1[0])+"\n"+(m1.mention if m1 else str(time1[0])),
                inline=True
            )
            embed.add_field(
                name="VERMELHO",
                value=rank_str(time2[0])+"\n"+(m2.mention if m2 else str(time2[0])),
                inline=True
            )
        else:
            embed.add_field(name="TIME 1  (AZUL)  | Cap: "+(cap1m.display_name if cap1m else str(capitao1)), value=time_block(time1,capitao1), inline=True)
            embed.add_field(name="TIME 2  (VERMELHO)  | Cap: "+(cap2m.display_name if cap2m else str(capitao2)), value=time_block(time2,capitao2), inline=True)

        embed.add_field(name="\u200b",value="\u200b",inline=False)
        embed.add_field(
            name="Como jogar",
            value=(
                "Mande o codigo da sala no chat (ex: 99398388  22)\n"
                "Use os botoes abaixo para gerenciar a partida\n"
                "A partida encerra automaticamente em 20 minutos"
            ),
            inline=False
        )
        embed.set_footer(text="RANKED Mobile  |  Boa partida!")
        await canal.send(embed=embed, view=PartidaRankedView(canal.id))
        asyncio.create_task(timer_ranked(canal.id))
    except Exception as e: print("[ERRO criar_partida_ranked] "+str(e))

# ================================================================
#   VIEW PARTIDA RANKED
# ================================================================

class PartidaRankedView(discord.ui.View):
    def __init__(self, canal_id):
        super().__init__(timeout=None)
        self.canal_id = canal_id

    @discord.ui.button(label="Definir Vencedor", style=discord.ButtonStyle.success, custom_id="rv_venc", row=0)
    async def vencedor(self, interaction, button):
        try:
            info = partidas_ativas.get(interaction.channel_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            if interaction.user.id not in info["jogadores"]: return await interaction.response.send_message("Voce nao esta nesta partida.", ephemeral=True)
            if info["tipo"]=="1v1":
                view = VotoVenc1v1(interaction.channel_id, info, interaction.guild)
            else:
                view = VotoVencTime(interaction.channel_id, info)
            embed = discord.Embed(title="Definir Vencedor", description="Selecione o vencedor abaixo:", color=0x00ff55)
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        except Exception as e: print("[ERRO rv_venc] "+str(e))

    @discord.ui.button(label="Definir MVP", style=discord.ButtonStyle.success, custom_id="rv_mvp", row=0)
    async def mvp(self, interaction, button):
        try:
            info = partidas_ativas.get(interaction.channel_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            if interaction.user.id not in info["jogadores"]: return await interaction.response.send_message("Voce nao esta nesta partida.", ephemeral=True)
            guild = interaction.guild
            embed = discord.Embed(title="Definir MVP", color=0xffd700)
            t1 = info.get("time1",[]); t2 = info.get("time2",[])
            cap1=info.get("capitao1"); cap2=info.get("capitao2")
            def tinfo(tlist,cap):
                linhas=[]
                for u in tlist:
                    m=guild.get_member(u)
                    n=m.display_name if m else str(u)
                    p=get_perfil(u)
                    pref="[CAP] " if u==cap else ""
                    linhas.append(pref+rank_str(u)+" | "+n+" | "+str(p.get("pontos",0.0))+" pts")
                return "\n".join(linhas) or "---"
            embed.add_field(name="TIME 1  (AZUL)",     value=tinfo(t1,cap1), inline=True)
            embed.add_field(name="TIME 2  (VERMELHO)", value=tinfo(t2,cap2), inline=True)
            embed.add_field(name="\u200b",value="Selecione o MVP:",inline=False)
            await interaction.response.send_message(embed=embed, view=VotoMVP(interaction.channel_id,info,guild), ephemeral=True)
        except Exception as e: print("[ERRO rv_mvp] "+str(e))

    @discord.ui.button(label="Finalizar Partida", style=discord.ButtonStyle.danger, custom_id="rv_fim", row=1)
    async def finalizar(self, interaction, button):
        try:
            info = partidas_ativas.get(interaction.channel_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            if interaction.user.id not in info["jogadores"]: return await interaction.response.send_message("Voce nao esta nesta partida.", ephemeral=True)
            uid = str(interaction.user.id)
            if uid not in info["conf_fim"]: info["conf_fim"].append(uid)
            faltam = len(info["jogadores"])-len(info["conf_fim"])
            if faltam>0:
                await interaction.response.send_message("Aguardando "+str(faltam)+" confirmacao(oes).", ephemeral=True)
            else:
                await interaction.response.send_message("Finalizando...", ephemeral=True)
                asyncio.create_task(finalizar_ranked(interaction.channel, info))
        except Exception as e: print("[ERRO rv_fim] "+str(e))

    @discord.ui.button(label="Chamar Room", style=discord.ButtonStyle.secondary, custom_id="rv_room", row=1)
    async def room(self, interaction, button):
        try:
            info  = partidas_ativas.get(interaction.channel_id)
            guild = interaction.guild
            ch    = guild.get_channel(SUPORTE_CHANNEL_ID)
            role  = guild.get_role(SUPORTE_ROLE_ID)
            if ch and role:
                mencoes = " ".join((guild.get_member(u).mention if guild.get_member(u) else str(u)) for u in (info["jogadores"] if info else []))
                await ch.send(
                    role.mention+"\nROOM SOLICITADO\nPor: "+interaction.user.mention+"\nCanal: "+interaction.channel.mention+"\nJogadores: "+mencoes,
                    view=SuporteAdmView(interaction.channel_id, info["jogadores"] if info else [])
                )
                await interaction.response.send_message("Room notificado! Aguarde.", ephemeral=True)
            else:
                await interaction.response.send_message("Canal de suporte nao configurado.", ephemeral=True)
        except Exception as e: print("[ERRO rv_room] "+str(e))

# ================================================================
#   VOTOS RANKED
# ================================================================

class VotoVenc1v1(discord.ui.View):
    def __init__(self, canal_id, info, guild):
        super().__init__(timeout=60)
        self.canal_id = canal_id
        for uid in info["jogadores"]:
            m = guild.get_member(uid)
            btn = discord.ui.Button(label=rank_str(uid)+" | "+(m.display_name if m else str(uid)), style=discord.ButtonStyle.success)
            def mk(t):
                async def cb(i): await self._propor(i,t)
                return cb
            btn.callback=mk(uid); self.add_item(btn)

    async def _propor(self, interaction, venc_id):
        try:
            info  = partidas_ativas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            guild = interaction.guild; canal = guild.get_channel(self.canal_id)
            venc  = guild.get_member(venc_id)
            cap1  = guild.get_member(info["capitao1"]); cap2 = guild.get_member(info["capitao2"])
            await interaction.response.send_message("Proposta enviada! Aguarde os capitaes confirmarem.", ephemeral=True); self.stop()
            if canal:
                embed = discord.Embed(title="Vencedor Proposto", color=0x00ff55)
                embed.add_field(name="Jogador", value=venc.mention if venc else str(venc_id), inline=False)
                embed.add_field(name="Pontos",  value="+"+str(PONTOS_VENCEDOR)+" ao finalizar", inline=False)
                await canal.send(
                    embed=embed,
                    content="Cap 1 ("+(cap1.mention if cap1 else str(info["capitao1"]))+") e Cap 2 ("+(cap2.mention if cap2 else str(info["capitao2"]))+") devem confirmar:",
                    view=ConfCapitaes(self.canal_id,info["capitao1"],info["capitao2"],"vencedor",venc_id)
                )
        except Exception as e: print("[ERRO VotoVenc1v1] "+str(e))

class VotoVencTime(discord.ui.View):
    def __init__(self, canal_id, info):
        super().__init__(timeout=60)
        self.canal_id=canal_id; self.info=info

    @discord.ui.button(label="TIME 1  (AZUL) Venceu",     style=discord.ButtonStyle.primary)
    async def t1(self, interaction, button): await self._propor(interaction,"time1")

    @discord.ui.button(label="TIME 2  (VERMELHO) Venceu", style=discord.ButtonStyle.danger)
    async def t2(self, interaction, button): await self._propor(interaction,"time2")

    async def _propor(self, interaction, ts):
        try:
            info  = partidas_ativas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            guild = interaction.guild; canal = guild.get_channel(self.canal_id)
            tnome = "TIME 1  (AZUL)" if ts=="time1" else "TIME 2  (VERMELHO)"
            cor   = 0x4169e1 if ts=="time1" else 0xdc143c
            cap1  = guild.get_member(info["capitao1"]); cap2 = guild.get_member(info["capitao2"])
            await interaction.response.send_message("Voce propos "+tnome+"!", ephemeral=True); self.stop()
            if canal:
                embed = discord.Embed(title="Vencedor Proposto", color=cor)
                embed.add_field(name="Time",   value=tnome, inline=False)
                embed.add_field(name="Pontos", value="+"+str(PONTOS_VENCEDOR)+" por jogador ao finalizar", inline=False)
                await canal.send(
                    embed=embed,
                    content="Cap 1 ("+(cap1.mention if cap1 else str(info["capitao1"]))+") e Cap 2 ("+(cap2.mention if cap2 else str(info["capitao2"]))+") devem confirmar:",
                    view=ConfCapitaes(self.canal_id,info["capitao1"],info["capitao2"],"vencedor",ts)
                )
        except Exception as e: print("[ERRO VotoVencTime] "+str(e))

class VotoMVP(discord.ui.View):
    def __init__(self, canal_id, info, guild):
        super().__init__(timeout=60)
        self.canal_id = canal_id
        for uid in info["jogadores"]:
            m = guild.get_member(uid)
            btn = discord.ui.Button(label=rank_str(uid)+" | "+(m.display_name if m else str(uid)), style=discord.ButtonStyle.success)
            def mk(t):
                async def cb(i): await self._propor(i,t)
                return cb
            btn.callback=mk(uid); self.add_item(btn)

    async def _propor(self, interaction, mvp_id):
        try:
            info  = partidas_ativas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            guild = interaction.guild; canal = guild.get_channel(self.canal_id)
            mvp_m = guild.get_member(mvp_id)
            cap1  = guild.get_member(info["capitao1"]); cap2 = guild.get_member(info["capitao2"])
            await interaction.response.send_message("MVP proposto: "+(mvp_m.display_name if mvp_m else str(mvp_id))+"!", ephemeral=True); self.stop()
            if canal:
                embed = discord.Embed(title="MVP Proposto", color=0xffd700)
                embed.add_field(name="Jogador", value=mvp_m.mention if mvp_m else str(mvp_id), inline=False)
                embed.add_field(name="Pontos",  value="+"+str(PONTOS_MVP)+" ao finalizar", inline=False)
                await canal.send(
                    embed=embed,
                    content="Cap 1 ("+(cap1.mention if cap1 else str(info["capitao1"]))+") e Cap 2 ("+(cap2.mention if cap2 else str(info["capitao2"]))+") devem confirmar:",
                    view=ConfCapitaes(self.canal_id,info["capitao1"],info["capitao2"],"mvp",mvp_id)
                )
        except Exception as e: print("[ERRO VotoMVP] "+str(e))

class ConfCapitaes(discord.ui.View):
    def __init__(self, canal_id, cap1, cap2, tipo, valor):
        super().__init__(timeout=300)
        self.canal_id=canal_id; self.cap1=cap1; self.cap2=cap2
        self.tipo=tipo; self.valor=valor; self.conf=[]

    @discord.ui.button(label="Confirmar", style=discord.ButtonStyle.success)
    async def confirmar(self, interaction, button):
        try:
            uid = interaction.user.id
            if uid not in [self.cap1,self.cap2]: return await interaction.response.send_message("Apenas capitaes podem confirmar.", ephemeral=True)
            if uid in self.conf: return await interaction.response.send_message("Voce ja confirmou!", ephemeral=True)
            self.conf.append(uid)
            if 2-len(self.conf)>0:
                await interaction.response.send_message("Confirmado! Aguardando o outro capitao.", ephemeral=True)
            else:
                info  = partidas_ativas.get(self.canal_id)
                canal = interaction.guild.get_channel(self.canal_id)
                if info: info[self.tipo] = self.valor
                await interaction.response.edit_message(content="Ambos os capitaes confirmaram!", embed=None, view=None); self.stop()
                if canal and info:
                    if self.tipo=="vencedor":
                        if str(self.valor).startswith("time"):
                            tnome="TIME 1  (AZUL)" if self.valor=="time1" else "TIME 2  (VERMELHO)"
                            cor=0x4169e1 if self.valor=="time1" else 0xdc143c
                            embed=discord.Embed(title="Vencedor Confirmado!", description=tnome, color=cor)
                        else:
                            m=interaction.guild.get_member(self.valor)
                            embed=discord.Embed(title="Vencedor Confirmado!", description=m.mention if m else str(self.valor), color=0x00ff55)
                        embed.set_footer(text="Clique em Finalizar Partida para encerrar!")
                        await canal.send(embed=embed)
                    elif self.tipo=="mvp":
                        m=interaction.guild.get_member(self.valor)
                        embed=discord.Embed(title="MVP Confirmado!", description=m.mention if m else str(self.valor), color=0xffd700)
                        embed.add_field(name="Pontos", value="+"+str(PONTOS_MVP)+" ao finalizar", inline=False)
                        await canal.send(embed=embed)
        except Exception as e: print("[ERRO ConfCapitaes] "+str(e))

    @discord.ui.button(label="Recusar", style=discord.ButtonStyle.danger)
    async def recusar(self, interaction, button):
        try:
            uid=interaction.user.id
            if uid not in [self.cap1,self.cap2]: return await interaction.response.send_message("Apenas capitaes.", ephemeral=True)
            canal=interaction.guild.get_channel(self.canal_id)
            if canal: await canal.send(interaction.user.mention+" recusou a proposta. Tente novamente ou chame o Room.")
            await interaction.response.edit_message(content="Proposta recusada.", view=None); self.stop()
        except Exception as e: print("[ERRO recusar] "+str(e))

class ConfirmarCriadorView(discord.ui.View):
    def __init__(self, canal_id, cand_id, codigo):
        super().__init__(timeout=120)
        self.canal_id=canal_id; self.cand_id=cand_id; self.codigo=codigo

    @discord.ui.button(label="Confirmar Criador", style=discord.ButtonStyle.success, row=0)
    async def confirmar(self, interaction, button):
        try:
            info=partidas_ativas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            if interaction.user.id not in info["jogadores"]: return await interaction.response.send_message("Apenas jogadores desta partida.", ephemeral=True)
            if interaction.user.id==self.cand_id: return await interaction.response.send_message("Voce nao pode confirmar a si mesmo.", ephemeral=True)
            info["criador"]=self.cand_id
            cand=interaction.guild.get_member(self.cand_id)
            await interaction.response.edit_message(content=(cand.display_name if cand else str(self.cand_id))+" confirmado como criador!", embed=None, view=None); self.stop()
            canal=interaction.guild.get_channel(self.canal_id)
            if canal:
                embed=discord.Embed(title="Criador Definido!", color=0x00aaff)
                embed.add_field(name="Criador",   value=cand.mention if cand else str(self.cand_id), inline=False)
                embed.add_field(name="Codigo",    value="```"+self.codigo+"```",                      inline=False)
                await canal.send(embed=embed)
        except Exception as e: print("[ERRO ConfirmarCriador] "+str(e))

    @discord.ui.button(label="Copiar ID", style=discord.ButtonStyle.success, row=0)
    async def copiar(self, interaction, button):
        await interaction.response.send_message("```"+self.codigo+"```", ephemeral=True)

class SuporteAdmView(discord.ui.View):
    def __init__(self, canal_id, jogadores):
        super().__init__(timeout=None)
        self.canal_id=canal_id; self.jogadores=jogadores

    @discord.ui.button(label="Definir Vencedor", style=discord.ButtonStyle.success, custom_id="sadm_v")
    async def sv(self, interaction, button):
        try:
            if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
            info=partidas_ativas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            view=VotoVenc1v1(self.canal_id,info,interaction.guild) if info["tipo"]=="1v1" else VotoVencTime(self.canal_id,info)
            await interaction.response.send_message("Selecione:", view=view, ephemeral=True)
        except Exception as e: print(e)

    @discord.ui.button(label="Finalizar", style=discord.ButtonStyle.danger, custom_id="sadm_f")
    async def sf(self, interaction, button):
        try:
            if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
            info=partidas_ativas.get(self.canal_id); canal=interaction.guild.get_channel(self.canal_id)
            if info and canal:
                await interaction.response.send_message("Finalizando...", ephemeral=True)
                asyncio.create_task(finalizar_ranked(canal, info, adm=interaction.user))
            else: await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
        except Exception as e: print(e)

# ================================================================
#   FINALIZAR RANKED
# ================================================================

async def finalizar_ranked(canal, info, adm=None):
    try:
        guild=canal.guild; jogadores=info["jogadores"]; tipo=info["tipo"]
        mvp_id=info.get("mvp"); vencedor=info.get("vencedor")
        vencedores=([vencedor] if vencedor else []) if tipo=="1v1" else (info.get(vencedor,[]) if vencedor in ("time1","time2") else [])
        ganhos={}
        for uid in jogadores:
            p=get_perfil(uid); ra=int(p.get("apelido_num") or 5000); pts=0.0
            if uid in vencedores:
                p["vitorias"]+=1; p["pontos"]=round(p["pontos"]+PONTOS_VENCEDOR,2); pts+=PONTOS_VENCEDOR; nr=max(1,ra+RANK_VITORIA)
            else:
                p["derrotas"]+=1; nr=min(9999,ra+RANK_DERROTA)
            if uid==mvp_id: p["mvps"]+=1; p["pontos"]=round(p["pontos"]+PONTOS_MVP,2); pts+=PONTOS_MVP
            p["apelido_num"]=str(nr); ganhos[uid]=pts
        salvar_dados()
        for uid in jogadores: await nick_update(guild, uid)

        embed=discord.Embed(title="Resultado Final  |  "+tipo.upper(), color=0x00ff55)
        embed.add_field(name="Modo", value=info.get("modo","?").replace("_"," ").title(), inline=True)

        if tipo=="1v1":
            vm=guild.get_member(vencedores[0]) if vencedores else None
            embed.add_field(name="Vencedor", value=vm.mention if vm else "Nao definido", inline=True)
        else:
            if vencedor in ("time1","time2"):
                tnome="TIME 1  (AZUL)" if vencedor=="time1" else "TIME 2  (VERMELHO)"
                cor=0x4169e1 if vencedor=="time1" else 0xdc143c
                mencoes=" | ".join(guild.get_member(u).mention if guild.get_member(u) else str(u) for u in vencedores)
                embed.add_field(name="Time Vencedor", value=tnome+"\n"+mencoes, inline=False)
            else:
                embed.add_field(name="Time Vencedor", value="Nao definido", inline=False)

        mvp_m=guild.get_member(mvp_id) if mvp_id else None
        embed.add_field(name="MVP", value=mvp_m.mention if mvp_m else "Nao definido", inline=True)
        embed.add_field(name="\u200b",value="Pontuacao:",inline=False)
        for uid in jogadores:
            m=guild.get_member(uid); p=get_perfil(uid); pts=ganhos.get(uid,0.0)
            embed.add_field(name=m.display_name if m else str(uid), value=("+"+str(pts) if pts>0 else str(pts))+" pts\nTotal: "+str(p["pontos"])+" pts\nRank: #"+str(p["apelido_num"]), inline=True)
        embed.set_footer(text="ADM: "+adm.display_name if adm else "Encerrado pelos jogadores.")
        await canal.send(embed=embed)
        await canal.send("Canal deletado em 15 segundos.")
        partidas_ativas.pop(canal.id,None)
        await asyncio.sleep(15)
        try: await canal.delete()
        except: pass
    except Exception as e:
        print("[ERRO finalizar_ranked] "+str(e))
        try: await canal.send("Erro ao finalizar. Chame o Room.")
        except: pass

async def timer_ranked(canal_id):
    await asyncio.sleep(1200)
    if canal_id not in partidas_ativas: return
    info=partidas_ativas[canal_id]; guild=bot.get_guild(GUILD_ID)
    if not guild: return
    canal=guild.get_channel(canal_id)
    if not canal: partidas_ativas.pop(canal_id,None); return
    await canal.send("Tempo esgotado! Encerrando automaticamente...")
    await finalizar_ranked(canal, info)

# ================================================================
#   CRIAR PARTIDA APOSTAS
# ================================================================

async def criar_partida_aposta(guild, jogadores, tipo, modo, valor):
    try:
        categoria    = guild.get_channel(APOSTA_CATEGORY_ID)
        suporte_role = guild.get_role(SUPORTE_ROLE_ID)
        num   = proximo_num_partida()
        overw = {guild.default_role: discord.PermissionOverwrite(read_messages=False)}
        for uid in jogadores:
            m=guild.get_member(uid)
            if m: overw[m]=discord.PermissionOverwrite(read_messages=True,send_messages=True)
        if suporte_role: overw[suporte_role]=discord.PermissionOverwrite(read_messages=True,send_messages=True)
        canal=await guild.create_text_channel("aposta-"+num, category=categoria, overwrites=overw)
        info={"jogadores":jogadores,"tipo":tipo,"modo":modo,"valor":valor,"adm_escolhido":None,"aceites":[],"canal_id":canal.id}
        aposta_partidas[canal.id]=info
        ml="Gelo Normal" if modo=="gelo_normal" else "Gelo Infinito"
        embed=discord.Embed(title="Aposta #"+num+"  |  "+tipo.upper(), color=0xffd700)
        embed.set_thumbnail(url=GIF_URL)
        embed.add_field(name="Tipo",  value=tipo.upper(), inline=True)
        embed.add_field(name="Modo",  value=ml,           inline=True)
        if valor: embed.add_field(name="Valor", value=valor, inline=True)
        mencoes=" vs ".join(guild.get_member(u).mention if guild.get_member(u) else str(u) for u in jogadores)
        embed.add_field(name="Jogadores", value=mencoes, inline=False)
        embed.add_field(name="Proximos passos", value="1. Aceite a partida\n2. Escolha o ADM\n3. Pague via PIX\n4. Jogue!\n\nCancelar: canal fecha em 4 segundos.", inline=False)
        await canal.send(embed=embed, view=ApostaPartidaView(canal.id, len(jogadores)))
        adm_ch=guild.get_channel(ADM_PARTIDAS_CHANNEL_ID)
        if adm_ch:
            mencoes_adm=" ".join(guild.get_member(u).mention if guild.get_member(u) else str(u) for u in adms_online) or "Nenhum ADM online"
            await adm_ch.send("NOVA PARTIDA DE APOSTA #"+num+"\nCanal: "+canal.mention+"\n"+tipo.upper()+" | "+ml+((" | "+valor) if valor else "")+"\nADMs: "+mencoes_adm)
    except Exception as e: print("[ERRO criar_partida_aposta] "+str(e))

class ApostaPartidaView(discord.ui.View):
    def __init__(self, canal_id, total):
        super().__init__(timeout=None)
        self.canal_id=canal_id; self.total=total

    @discord.ui.button(label="Aceitar Partida",  style=discord.ButtonStyle.success, custom_id="ap_ac")
    async def aceitar(self, interaction, button):
        try:
            info=aposta_partidas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            if interaction.user.id not in info["jogadores"]: return await interaction.response.send_message("Voce nao esta nesta partida.", ephemeral=True)
            uid=str(interaction.user.id)
            if uid in info["aceites"]: return await interaction.response.send_message("Voce ja aceitou!", ephemeral=True)
            info["aceites"].append(uid)
            faltam=self.total-len(info["aceites"])
            if faltam>0:
                await interaction.response.send_message("Aceite registrado! Aguardando "+str(faltam)+".", ephemeral=True)
                await interaction.channel.send(interaction.user.display_name+" aceitou! ("+str(len(info["aceites"]))+"/"+str(self.total)+")")
            else:
                await interaction.response.send_message("Todos aceitaram!", ephemeral=True)
                await interaction.channel.send("Todos aceitaram! Escolha o ADM:", view=EscolherADMView(self.canal_id))
        except Exception as e: print(e)

    @discord.ui.button(label="Cancelar Partida", style=discord.ButtonStyle.danger,   custom_id="ap_can")
    async def cancelar(self, interaction, button):
        try:
            info=aposta_partidas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            if interaction.user.id not in info["jogadores"]: return await interaction.response.send_message("Voce nao esta nesta partida.", ephemeral=True)
            await interaction.response.send_message("Cancelado.", ephemeral=True)
            await interaction.channel.send("PARTIDA CANCELADA por "+interaction.user.display_name+"!\nCanal fecha em 4 segundos.")
            aposta_partidas.pop(self.canal_id,None)
            await asyncio.sleep(4)
            try: await interaction.channel.delete()
            except: pass
        except Exception as e: print(e)

class EscolherADMView(discord.ui.View):
    def __init__(self, canal_id):
        super().__init__(timeout=None)
        self.canal_id=canal_id

    @discord.ui.button(label="Escolher ADM", style=discord.ButtonStyle.primary, custom_id="ap_adm")
    async def escolher(self, interaction, button):
        try:
            info=aposta_partidas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            if interaction.user.id not in info["jogadores"]: return await interaction.response.send_message("Voce nao esta nesta partida.", ephemeral=True)
            if not adms_online: return await interaction.response.send_message("Sem ADM disponivel.", ephemeral=True)
            await interaction.response.send_message("Selecione o ADM:", view=SelecionarADMView(self.canal_id), ephemeral=True)
        except Exception as e: print(e)

class SelecionarADMView(discord.ui.View):
    def __init__(self, canal_id):
        super().__init__(timeout=60)
        self.canal_id=canal_id
        for uid in adms_online:
            d=adms_dados.get(str(uid),{}); nome=d.get("nome",str(uid))
            btn=discord.ui.Button(label=nome, style=discord.ButtonStyle.success)
            def mk(t):
                async def cb(i): await self._sel(i,t)
                return cb
            btn.callback=mk(uid); self.add_item(btn)

    async def _sel(self, interaction, adm_uid):
        try:
            info=aposta_partidas.get(self.canal_id)
            if not info: return await interaction.response.send_message("Partida nao encontrada.", ephemeral=True)
            info["adm_escolhido"]=adm_uid
            d=adms_dados.get(str(adm_uid),{}); nome=d.get("nome",str(adm_uid)); pix=d.get("pix","?"); qr=d.get("qr","")
            guild=interaction.guild; adm_m=guild.get_member(adm_uid)
            embed=discord.Embed(title="ADM Selecionado", color=0x00aaff)
            embed.add_field(name="ADM",       value=adm_m.mention if adm_m else nome, inline=False)
            embed.add_field(name="Chave PIX", value="```"+pix+"```", inline=False)
            if qr: embed.add_field(name="QR Code", value=qr, inline=False)
            embed.set_footer(text="Pague o valor via PIX antes de iniciar!")
            canal=guild.get_channel(self.canal_id)
            if canal:
                await canal.send(embed=embed)
                if adm_m: await canal.send(adm_m.mention+" voce foi escolhido como ADM desta partida!")
            await interaction.response.send_message("ADM "+nome+" selecionado!", ephemeral=True); self.stop()
        except Exception as e: print(e)

# ================================================================
#   SISTEMA DE ROOM (TICKET)
# ================================================================

def build_room_painel():
    embed=discord.Embed(title="ROOM  |  Suporte Ranked", description="Precisa de ajuda? Abra um Room e a equipe ira te atender!", color=0x5865f2)
    embed.set_thumbnail(url=GIF_URL)
    embed.add_field(name="Como funciona", value="1. Clique em Abrir Room\n2. Canal privado sera criado\n3. Descreva o problema\n4. A equipe Room ira te atender\n5. Use /fechar_room para encerrar", inline=False)
    embed.set_footer(text="Use apenas para duvidas ou problemas reais")
    return embed

class RoomPainelView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)

    @discord.ui.button(label="Abrir Room", style=discord.ButtonStyle.primary, custom_id="room_abrir")
    async def abrir(self, interaction, button):
        try:
            guild=interaction.guild; uid=interaction.user.id
            for info in tickets_abertos.values():
                if info["uid"]==uid: return await interaction.response.send_message("Voce ja tem um Room aberto!", ephemeral=True)
            num=proximo_num_ticket()
            ticket_role=guild.get_role(TICKET_ROLE_ID); categoria=guild.get_channel(TICKET_CATEGORY_ID)
            overw={
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user:   discord.PermissionOverwrite(read_messages=True,send_messages=True),
            }
            if ticket_role: overw[ticket_role]=discord.PermissionOverwrite(read_messages=True,send_messages=True)
            canal=await guild.create_text_channel("room-"+num, category=categoria, overwrites=overw, topic="Room de "+interaction.user.display_name)
            tickets_abertos[canal.id]={"uid":uid,"num":num,"notificado":False}
            embed=discord.Embed(title="Room #"+num, description=interaction.user.mention+" bem-vindo!\nDescreva seu problema e a equipe Room ira te responder.", color=0x5865f2)
            embed.set_thumbnail(url=GIF_URL)
            embed.add_field(name="Status", value="Aguardando atendimento...", inline=False)
            embed.set_footer(text="Use /fechar_room para encerrar")
            await canal.send(embed=embed, view=RoomCanalView(canal.id))
            if ticket_role: await canal.send(ticket_role.mention+" novo Room aguardando atendimento!")
            await interaction.response.send_message("Room criado! "+canal.mention, ephemeral=True)
        except Exception as e: print("[ERRO abrir_room] "+str(e))

class RoomCanalView(discord.ui.View):
    def __init__(self, canal_id):
        super().__init__(timeout=None); self.canal_id=canal_id

    @discord.ui.button(label="Fechar Room", style=discord.ButtonStyle.danger, custom_id="room_fechar")
    async def fechar(self, interaction, button):
        try:
            info_t=tickets_abertos.get(self.canal_id); tr=interaction.guild.get_role(TICKET_ROLE_ID)
            pode=(info_t and interaction.user.id==info_t["uid"]) or (tr and tr in interaction.user.roles) or interaction.user.guild_permissions.administrator
            if not pode: return await interaction.response.send_message("Apenas o dono ou Room pode fechar.", ephemeral=True)
            await interaction.response.send_message("Fechando em 5 segundos...")
            tickets_abertos.pop(self.canal_id,None)
            await asyncio.sleep(5)
            try: await interaction.channel.delete()
            except: pass
        except Exception as e: print(e)

# ================================================================
#   DASHBOARD
# ================================================================

def build_dashboard(guild):
    embed=discord.Embed(title="DASHBOARD  |  RANKED", description="Painel de controle. Apenas o dono.", color=0xff6600)
    embed.set_thumbnail(url=GIF_URL)
    tb=guild.member_count; bots=sum(1 for m in guild.members if m.bot)
    embed.add_field(name="Membros",       value=str(tb-bots),             inline=True)
    embed.add_field(name="Bots",          value=str(bots),                inline=True)
    embed.add_field(name="Cargos",        value=str(len(guild.roles)),    inline=True)
    embed.add_field(name="Canais",        value=str(len(guild.channels)), inline=True)
    embed.add_field(name="Jogadores",     value=str(len(dados["jogadores"])), inline=True)
    embed.add_field(name="ADMs online",   value=str(len(adms_online)),    inline=True)
    embed.add_field(name="Partidas",      value=str(len(partidas_ativas)+len(aposta_partidas)), inline=True)
    embed.add_field(name="Rooms abertos", value=str(len(tickets_abertos)),inline=True)
    filas_ativas=[t+" "+m.replace("_"," ").title()+": "+str(len(filas[t][m])) for t in ["1v1","2v2","3v3"] for m in ["gelo_normal","gelo_infinito"] if len(filas[t][m])>0]
    embed.add_field(name="Filas", value="\n".join(filas_ativas) if filas_ativas else "Nenhuma", inline=False)
    embed.set_footer(text="Atualizado: "+datetime.now().strftime("%d/%m %H:%M"))
    return embed

class DashboardView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)

    def _ok(self, i): return i.user.id==i.guild.owner_id

    @discord.ui.button(label="Atualizar",          style=discord.ButtonStyle.primary,   custom_id="d_up",    row=0)
    async def up(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        await i.response.edit_message(embed=build_dashboard(i.guild), view=self)

    @discord.ui.button(label="Limpar Ranked",      style=discord.ButtonStyle.danger,    custom_id="d_cr",    row=0)
    async def cr(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        for tf in filas.values():
            for l in tf.values(): l.clear()
        for t in ["2v2","3v3"]:
            for m in ["gelo_normal","gelo_infinito"]:
                filas_times[t][m]["time1"].clear(); filas_times[t][m]["time2"].clear()
        asyncio.create_task(update_all_ranked(i.guild))
        await i.response.send_message("Filas ranked limpas!", ephemeral=True)

    @discord.ui.button(label="Limpar Apostas",     style=discord.ButtonStyle.danger,    custom_id="d_ca",    row=0)
    async def ca(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        for md in aposta_filas_1v1.values():
            for l in md.values(): l.clear()
        for td in aposta_filas_eq.values():
            for l in td.values(): l.clear()
        asyncio.create_task(update_all_apostas(i.guild))
        await i.response.send_message("Filas apostas limpas!", ephemeral=True)

    @discord.ui.button(label="Criar Cargos",       style=discord.ButtonStyle.success,   custom_id="d_cc",    row=1)
    async def cc(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        await i.response.send_message("Criando cargos...", ephemeral=True)
        cargos=[("Dono",0xFF0000,True),("Gerente",0xFF4500,True),("ADM",0xFF6600,True),("Room",0x5865F2,True),("Organizador",0x9B59B6,True),("Streamer",0x9146FF,False),("VIP",0xFFD700,False),("Pro Player",0x00CED1,False),("Verificado",0x2ECC71,False),("Membro",0x3498DB,False),("Novato",0x95A5A6,False)]
        ex=[r.name for r in i.guild.roles]; criados=[]
        for nome,cor,h in cargos:
            if nome not in ex: await i.guild.create_role(name=nome,color=discord.Color(cor),hoist=h,mentionable=True); criados.append(nome); await asyncio.sleep(0.5)
        await i.edit_original_response(content=("Criados: "+", ".join(criados)) if criados else "Todos os cargos ja existem!")

    @discord.ui.button(label="Criar Canais",       style=discord.ButtonStyle.success,   custom_id="d_ch",    row=1)
    async def ch_(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        await i.response.send_message("Criando canais...", ephemeral=True)
        ex=[c.name for c in i.guild.channels]; criados=[]
        estrutura=[
            ("INFORMACOES",["anuncios","regras","boas-vindas"],[]),
            ("RANKED 1v1",["ranked-1v1-mobile"],["Call Ranked 1v1"]),
            ("RANKED 2v2",["ranked-2v2-mobile"],["Call Ranked 2v2"]),
            ("RANKED 3v3",["ranked-3v3-mobile"],["Call Ranked 3v3"]),
            ("APOSTAS 1v1",["apostas-1v1-mobile"],[]),
            ("APOSTAS EQUIPE",["apostas-2v2","apostas-3v3","apostas-4v4"],[]),
            ("STAFF",["adm-partidas","dashboard","resultados"],["Call Staff"]),
            ("ROOM",["abrir-room"],[]),
            ("PARTIDAS RANKED",[],[]),
            ("PARTIDAS APOSTAS",[],[]),
            ("ROOMS",[],[]),
        ]
        for nc,ts,vs in estrutura:
            cat=discord.utils.get(i.guild.categories,name=nc)
            if not cat: cat=await i.guild.create_category(nc); criados.append("Cat:"+nc); await asyncio.sleep(0.3)
            for t in ts:
                if t not in ex: await i.guild.create_text_channel(t,category=cat); criados.append("#"+t); await asyncio.sleep(0.3)
            for v in vs:
                if v not in ex: await i.guild.create_voice_channel(v,category=cat); criados.append("voz:"+v); await asyncio.sleep(0.3)
        await i.edit_original_response(content=("Criados: "+", ".join(criados[:25])) if criados else "Tudo ja existe!")

    @discord.ui.button(label="Fechar Partidas",    style=discord.ButtonStyle.secondary, custom_id="d_fp",    row=2)
    async def fp(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        t=len(partidas_ativas)+len(aposta_partidas); partidas_ativas.clear(); aposta_partidas.clear()
        await i.response.send_message("Limpei "+str(t)+" partidas.", ephemeral=True)

    @discord.ui.button(label="ADMs Online",        style=discord.ButtonStyle.secondary, custom_id="d_adm",   row=2)
    async def adm_(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        if not adms_online: return await i.response.send_message("Nenhum ADM online.", ephemeral=True)
        linhas=[((i.guild.get_member(u).mention if i.guild.get_member(u) else str(u))+" | "+adms_dados.get(str(u),{}).get("pix","?")) for u in adms_online]
        await i.response.send_message("\n".join(linhas), ephemeral=True)

    @discord.ui.button(label="Purge 20 Mensagens", style=discord.ButtonStyle.secondary, custom_id="d_pur",   row=2)
    async def pur(self, i, b):
        if not self._ok(i): return await i.response.send_message("Apenas o dono.", ephemeral=True)
        try:
            deleted=await i.channel.purge(limit=20,check=lambda m: not m.pinned)
            await i.response.send_message("Deletei "+str(len(deleted))+" mensagens.", ephemeral=True)
        except Exception as e: await i.response.send_message("Erro: "+str(e), ephemeral=True)

    @discord.ui.button(label="Trocar Jogador de Time", style=discord.ButtonStyle.primary, custom_id="d_tt",  row=3)
    async def tt(self, i, b):
        if not self._ok(i) and not is_adm(i): return await i.response.send_message("Sem permissao.", ephemeral=True)
        await i.response.send_message("Use `/trocar_time @jogador 2v2 gelo_normal` para trocar jogador de time.", ephemeral=True)

# ================================================================
#   EMBED DE REGRAS
# ================================================================

def build_regras():
    embed = discord.Embed(
        title="REGRAS OFICIAIS  |  RANQUEADA LX",
        description="Leia todas as regras antes de jogar. Ao participar voce concorda com tudo abaixo.",
        color=0xffd700
    )
    embed.set_thumbnail(url=GIF_URL)
    embed.add_field(name="MODOS DISPONIVEIS", value="1x1  |  2x2  |  3x3  |  4x4\nQualquer outro modo = NAO PERMITIDO", inline=False)
    embed.add_field(
        name="PERSONAGENS PERMITIDOS",
        value="Jota | Leon | Kelly | Moco | Maxim | Alok\nFora da lista = DESCLASSIFICACAO IMEDIATA",
        inline=False
    )
    embed.add_field(
        name="ARMAS PERMITIDAS",
        value="UMP | XM8 | MP40\nQualquer outra arma = PROIBIDO",
        inline=False
    )
    embed.add_field(
        name="REGRA DA DESERT",
        value="Permitida apenas no PRIMEIRO ROUND\nApos o primeiro round = PROIBIDA",
        inline=False
    )
    embed.add_field(
        name="REGRAS DE COMBATE",
        value="Proibido usar granadas\nProibido armas nao permitidas\nProibido personagens proibidos\nProibido hack ou trapaca\nProibido abusar de bugs",
        inline=False
    )
    embed.add_field(
        name="GLOO WALL (GELO)",
        value="Uso liberado\nProibido: bug de gelo | abusar de falhas do jogo",
        inline=False
    )
    embed.add_field(
        name="BOA CONDUTA",
        value="Espere o outro jogador se preparar\nJogue na moral (sem apelar)\nRespeite todos\nEvite toxicidade e xingamentos",
        inline=False
    )
    embed.add_field(
        name="RESULTADO",
        value="Quebrou regra = PERDE NA HORA\nEm caso de duvida: Staff decide. Decisao final.",
        inline=False
    )
    embed.add_field(
        name="SISTEMA DE PROVAS",
        value="Recomendado gravar TODAS as partidas\nSem prova = sem revisao\nVideo deve estar claro",
        inline=False
    )
    embed.add_field(
        name="PUNICOES",
        value="1. Aviso | 2. Derrota | 3. Ban\nHack = BANIMENTO IMEDIATO",
        inline=False
    )
    embed.add_field(
        name="REGRAS FINAIS",
        value="Entrou = concordou com tudo\nJogue limpo | Respeite todos",
        inline=False
    )
    embed.set_footer(text="BOA SORTE E BOAS PARTIDAS!")
    return embed

# ================================================================
#   ON_MESSAGE
# ================================================================

@bot.event
async def on_message(message):
    if message.author.bot: return

    info = partidas_ativas.get(message.channel.id)
    if info and message.author.id in info["jogadores"]:
        texto = message.content.strip()
        if not texto.startswith("/") and not texto.startswith("!") and parece_codigo(texto):
            embed=discord.Embed(title="Codigo de Sala Detectado", description=message.author.display_name+" enviou:\n```"+texto+"```\nO oponente confirma abaixo:", color=0x00aaff)
            await message.channel.send(embed=embed, view=ConfirmarCriadorView(message.channel.id, message.author.id, texto))

    if message.channel.id in tickets_abertos and not message.author.bot:
        info_t=tickets_abertos[message.channel.id]
        if info_t.get("uid")==message.author.id and not info_t.get("notificado"):
            info_t["notificado"]=True
            tr=message.guild.get_role(TICKET_ROLE_ID)
            embed=discord.Embed(title="Caso Enviado!", description=message.author.mention+" seu caso foi enviado!\nNossa equipe Room ira te atender em breve. Aguarde.", color=0x00ff55)
            embed.set_footer(text="Room #"+info_t.get("num","????"))
            await message.channel.send(embed=embed)
            if tr: await message.channel.send(tr.mention+" ha um novo caso aguardando!")

    await bot.process_commands(message)

# ================================================================
#   EVENTO MEMBRO ENTRA
# ================================================================

@bot.event
async def on_member_join(member):
    guild=member.guild
    role=guild.get_role(NOVATO_ROLE_ID)
    if role:
        try: await member.add_roles(role)
        except Exception as e: print("[ERRO cargo] "+str(e))
    perfil=get_perfil(member.id)
    if not perfil.get("apelido_num"): perfil["apelido_num"]=numero_unico(); salvar_dados()
    nick=("RANK "+str(perfil["apelido_num"])+" | "+member.name)[:32]
    try: await member.edit(nick=nick)
    except Exception as e: print("[ERRO nick] "+str(e))

# ================================================================
#   COMANDOS SLASH
# ================================================================

@tree.command(name="perfil", description="Mostra seu perfil")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def cmd_perfil(interaction, usuario: discord.Member = None):
    try:
        alvo=usuario or interaction.user; p=get_perfil(alvo.id)
        total=p["vitorias"]+p["derrotas"]; wr=round(p["vitorias"]/max(total,1)*100,1)
        embed=discord.Embed(title="PERFIL  |  "+rank_str(alvo.id), description=alvo.display_name, color=0x00aaff)
        embed.set_thumbnail(url=alvo.display_avatar.url)
        embed.add_field(name="Pontos",   value=str(p["pontos"]),   inline=True)
        embed.add_field(name="Vitorias", value=str(p["vitorias"]), inline=True)
        embed.add_field(name="Derrotas", value=str(p["derrotas"]), inline=True)
        embed.add_field(name="MVPs",     value=str(p["mvps"]),     inline=True)
        embed.add_field(name="Partidas", value=str(total),         inline=True)
        embed.add_field(name="Win Rate", value=str(wr)+"%",        inline=True)
        embed.set_footer(text="Menor Rank = melhor posicao!")
        await interaction.response.send_message(embed=embed)
    except Exception as e:
        print(e)
        try: await interaction.response.send_message("Erro.", ephemeral=True)
        except: pass

@tree.command(name="ranking", description="Top 10 jogadores")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def cmd_ranking(interaction):
    try:
        j=dados.get("jogadores",{}); cr=[(u,p) for u,p in j.items() if p.get("apelido_num")]
        if not cr: return await interaction.response.send_message("Nenhum jogador.", ephemeral=True)
        top=sorted(cr,key=lambda x:int(x[1].get("apelido_num",9999)))[:10]
        embed=discord.Embed(title="RANKING TOP 10", color=0xffd700)
        embed.set_footer(text="Menor rank = melhor posicao")
        guild=interaction.guild
        for idx,(uid,p) in enumerate(top,1):
            m=guild.get_member(int(uid)); nm=m.display_name if m else "ID "+uid
            total=p.get("vitorias",0)+p.get("derrotas",0); wr=round(p.get("vitorias",0)/max(total,1)*100,1)
            pos=["1.","2.","3."][idx-1] if idx<=3 else str(idx)+"."
            embed.add_field(name=pos+" "+nm+" | RANK #"+str(p.get("apelido_num","????")),
                            value=str(p.get("pontos",0.0))+" pts | "+str(p.get("vitorias",0))+"V "+str(p.get("derrotas",0))+"D | "+str(p.get("mvps",0))+" MVPs | "+str(wr)+"% WR",inline=False)
        await interaction.response.send_message(embed=embed)
    except Exception as e:
        print(e)
        try: await interaction.response.send_message("Erro.", ephemeral=True)
        except: pass

async def _setup_ranked(interaction, tipo):
    try:
        if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        await interaction.response.send_message("Enviando...", ephemeral=True)
        msg=await interaction.channel.send(embed=get_embed_ranked(tipo), view=PainelRankedView(tipo))
        painel_ids[tipo]=msg.id; painel_canal_ids[tipo]=interaction.channel.id
        cfg=carregar_json(FILA_MSG_FILE,{}); cfg[tipo+"_msg"]=msg.id; cfg[tipo+"_canal"]=interaction.channel.id; salvar_fila(cfg)
        await interaction.edit_original_response(content="Painel "+tipo+" enviado!")
    except Exception as e:
        print(e)
        try: await interaction.edit_original_response(content="Erro: "+str(e))
        except: pass

@tree.command(name="setup_1v1",description="ADM - Painel ranked 1v1 neste canal")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def s1(interaction): await _setup_ranked(interaction,"1v1")

@tree.command(name="setup_2v2",description="ADM - Painel ranked 2v2 neste canal")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def s2(interaction): await _setup_ranked(interaction,"2v2")

@tree.command(name="setup_3v3",description="ADM - Painel ranked 3v3 neste canal")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def s3(interaction): await _setup_ranked(interaction,"3v3")

async def _setup_aposta(interaction, tipo):
    try:
        if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        await interaction.response.send_message("Enviando "+str(len(VALORES_APOSTA))+" paineis...", ephemeral=True)
        if tipo not in aposta_painel_val_ids: aposta_painel_val_ids[tipo]={}
        cfg=carregar_json(APOSTA_CFG_FILE,{})
        for valor in VALORES_APOSTA:
            if tipo=="1v1": msg=await interaction.channel.send(embed=build_aposta_1v1(valor), view=ApostaVal1v1View(valor))
            else:           msg=await interaction.channel.send(embed=build_aposta_eq(tipo,valor), view=ApostaValEqView(tipo,valor))
            aposta_painel_val_ids[tipo][valor]={"msg":msg.id,"canal":interaction.channel.id}
            cfg[tipo+"_"+valor+"_msg"]=msg.id; cfg[tipo+"_"+valor+"_canal"]=interaction.channel.id
            await asyncio.sleep(0.5)
        salvar_json(APOSTA_CFG_FILE,cfg)
        await interaction.edit_original_response(content="Paineis de apostas "+tipo+" enviados!")
    except Exception as e:
        print(e)
        try: await interaction.edit_original_response(content="Erro: "+str(e))
        except: pass

@tree.command(name="setup_aposta_1v1",description="ADM - Paineis apostas 1v1")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def sa1(interaction): await _setup_aposta(interaction,"1v1")

@tree.command(name="setup_aposta_2v2",description="ADM - Paineis apostas 2v2")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def sa2(interaction): await _setup_aposta(interaction,"2v2")

@tree.command(name="setup_aposta_3v3",description="ADM - Paineis apostas 3v3")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def sa3(interaction): await _setup_aposta(interaction,"3v3")

@tree.command(name="setup_aposta_4v4",description="ADM - Paineis apostas 4v4")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def sa4(interaction): await _setup_aposta(interaction,"4v4")

@tree.command(name="setup_adm",description="ADM - Painel ADM neste canal")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def setup_adm(interaction):
    global adm_painel_msg_id
    try:
        if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        await interaction.response.send_message("Enviando...", ephemeral=True)
        msg=await interaction.channel.send(embed=build_adm_painel(), view=ADMPainelView())
        adm_painel_msg_id=msg.id
        cfg=carregar_json(APOSTA_CFG_FILE,{}); cfg["adm_msg"]=msg.id; salvar_json(APOSTA_CFG_FILE,cfg)
        await interaction.edit_original_response(content="Painel ADM enviado!")
    except Exception as e:
        print(e)
        try: await interaction.edit_original_response(content="Erro: "+str(e))
        except: pass

@tree.command(name="setup_room",description="ADM - Painel Room neste canal")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def setup_room(interaction):
    try:
        if not is_adm(interaction) and interaction.user.id!=interaction.guild.owner_id: return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        await interaction.response.send_message("Enviando...", ephemeral=True)
        await interaction.channel.send(embed=build_room_painel(), view=RoomPainelView())
        await interaction.edit_original_response(content="Painel Room enviado!")
    except Exception as e:
        print(e)
        try: await interaction.edit_original_response(content="Erro: "+str(e))
        except: pass

@tree.command(name="setup_dashboard",description="DONO - Painel dashboard neste canal")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def setup_dashboard(interaction):
    try:
        if interaction.user.id!=interaction.guild.owner_id: return await interaction.response.send_message("Apenas o dono.", ephemeral=True)
        await interaction.response.send_message("Enviando...", ephemeral=True)
        await interaction.channel.send(embed=build_dashboard(interaction.guild), view=DashboardView())
        await interaction.edit_original_response(content="Dashboard enviado!")
    except Exception as e:
        print(e)
        try: await interaction.edit_original_response(content="Erro: "+str(e))
        except: pass

@tree.command(name="setup_regras",description="ADM - Envia embed de regras neste canal")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def setup_regras(interaction):
    try:
        if not is_adm(interaction) and interaction.user.id!=interaction.guild.owner_id: return await interaction.response.send_message("Sem permissao.", ephemeral=True)
        await interaction.response.send_message("Enviando regras...", ephemeral=True)
        await interaction.channel.send(embed=build_regras())
        await interaction.edit_original_response(content="Regras enviadas!")
    except Exception as e:
        print(e)

@tree.command(name="fechar_room",description="Room - Fecha o room atual")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def fechar_room(interaction):
    tr=interaction.guild.get_role(TICKET_ROLE_ID); info_t=tickets_abertos.get(interaction.channel_id)
    pode=(info_t and interaction.user.id==info_t["uid"]) or (tr and tr in interaction.user.roles) or interaction.user.guild_permissions.administrator
    if not pode: return await interaction.response.send_message("Apenas o dono do room ou Room.", ephemeral=True)
    await interaction.response.send_message("Fechando em 5 segundos...")
    tickets_abertos.pop(interaction.channel_id,None)
    await asyncio.sleep(5)
    try: await interaction.channel.delete()
    except: pass

@tree.command(name="trocar_time",description="ADM - Troca jogador de time na fila")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def trocar_time(interaction, jogador: discord.Member, tipo: str, modo: str):
    if not is_adm(interaction) and interaction.user.id!=interaction.guild.owner_id: return await interaction.response.send_message("Sem permissao.", ephemeral=True)
    if tipo not in ("2v2","3v3"): return await interaction.response.send_message("Tipo: 2v2 ou 3v3", ephemeral=True)
    if modo not in ("gelo_normal","gelo_infinito"): return await interaction.response.send_message("Modo: gelo_normal ou gelo_infinito", ephemeral=True)
    uid=jogador.id; times=filas_times[tipo][modo]
    if uid in times["time1"]: times["time1"].remove(uid); times["time2"].append(uid); await interaction.response.send_message(jogador.mention+" movido para TIME 2!", ephemeral=True)
    elif uid in times["time2"]: times["time2"].remove(uid); times["time1"].append(uid); await interaction.response.send_message(jogador.mention+" movido para TIME 1!", ephemeral=True)
    else: return await interaction.response.send_message("Jogador nao encontrado na fila.", ephemeral=True)
    asyncio.create_task(update_ranked(interaction.guild, tipo))

@tree.command(name="resetar_perfil",description="ADM - Reseta perfil de um jogador")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def resetar_perfil(interaction, usuario: discord.Member):
    if not is_adm(interaction): return await interaction.response.send_message("Sem permissao.", ephemeral=True)
    uid=str(usuario.id)
    if uid in dados["jogadores"]:
        num=dados["jogadores"][uid].get("apelido_num")
        dados["jogadores"][uid]={"vitorias":0,"derrotas":0,"pontos":0.0,"mvps":0,"apelido_num":num}; salvar_dados()
        await interaction.response.send_message("Perfil de "+usuario.mention+" resetado.", ephemeral=True)
    else: await interaction.response.send_message("Jogador nao encontrado.", ephemeral=True)

@tree.command(name="testar_aposta",description="DONO - Testa sistema de apostas")
@app_commands.guilds(discord.Object(id=GUILD_ID))
async def testar_aposta(interaction):
    if interaction.user.id!=interaction.guild.owner_id: return await interaction.response.send_message("Apenas o dono.", ephemeral=True)
    await interaction.response.send_message("Iniciando teste...", ephemeral=True)
    uid=str(interaction.user.id)
    adms_dados[uid]={"nome":"[TESTE] "+interaction.user.display_name,"pix":"teste@email.com","qr":""}
    salvar_adms(); adms_online.add(interaction.user.id)
    aposta_filas_1v1["R$ 1,00"]["gelo_normal"]=[interaction.user.id, interaction.user.id]
    j1=aposta_filas_1v1["R$ 1,00"]["gelo_normal"].pop(0); j2=aposta_filas_1v1["R$ 1,00"]["gelo_normal"].pop(0)
    asyncio.create_task(criar_partida_aposta(interaction.guild,[j1,j2],"1v1","gelo_normal","R$ 1,00"))
    asyncio.create_task(update_adm_painel(interaction.guild))
    await interaction.edit_original_response(content="Teste criado! ADM registrado com PIX: teste@email.com")

# ================================================================
#   ON READY
# ================================================================

@bot.event
async def on_ready():
    global adm_painel_msg_id
    for t in ["1v1","2v2","3v3"]: bot.add_view(PainelRankedView(t))
    for v in VALORES_APOSTA:
        bot.add_view(ApostaVal1v1View(v))
        for t in ["2v2","3v3","4v4"]: bot.add_view(ApostaValEqView(t,v))
    bot.add_view(ADMPainelView())
    bot.add_view(DashboardView())
    bot.add_view(RoomPainelView())
    for cid in list(partidas_ativas.keys()): bot.add_view(PartidaRankedView(cid))
    for cid in list(aposta_partidas.keys()): bot.add_view(ApostaPartidaView(cid,2))

    cfg=carregar_json(FILA_MSG_FILE,{})
    for t in ["1v1","2v2","3v3"]:
        if t+"_msg"   in cfg: painel_ids[t]      =int(cfg[t+"_msg"])
        if t+"_canal" in cfg: painel_canal_ids[t] =int(cfg[t+"_canal"])

    acfg=carregar_json(APOSTA_CFG_FILE,{})
    if "adm_msg" in acfg: adm_painel_msg_id=int(acfg["adm_msg"])
    for t in ["1v1","2v2","3v3","4v4"]:
        if t not in aposta_painel_val_ids: aposta_painel_val_ids[t]={}
        for v in VALORES_APOSTA:
            km=t+"_"+v+"_msg"; kc=t+"_"+v+"_canal"
            if km in acfg: aposta_painel_val_ids[t][v]={"msg":int(acfg[km]),"canal":int(acfg.get(kc,0))}

    try:
        await tree.sync(guild=discord.Object(id=GUILD_ID))
        print("[OK] Comandos sincronizados!")
    except Exception as e: print("[ERRO sync] "+str(e))

    print("[OK] Bot online: "+str(bot.user))
    print("[OK] Jogadores: "+str(len(dados["jogadores"])))
    print("[OK] ADMs: "+str(len(adms_dados)))

    guild=bot.get_guild(GUILD_ID)
    if guild:
        await update_all_ranked(guild)
        await update_all_apostas(guild)
        await update_adm_painel(guild)

bot.run(TOKEN)
